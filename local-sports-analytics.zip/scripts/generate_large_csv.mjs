import fs from 'node:fs';
const out=new URL('../large_sports_200k.csv',import.meta.url); const ws=fs.createWriteStream(out);
ws.write('player,player_id,team,season,month,venue,at_bats,hits,minutes,points,goals,result\n');
const players=['A. Sharma','J. Smith','M. Patel','L. Brown','K. Tanaka','S. Garcia']; const teams=['Chennai','Mumbai','London FC','Madrid SC'];
for(let i=0;i<200000;i++){const ab=20+(i*7)%180; ws.write(`${players[i%6]},P${1000+i%500},${teams[i%4]},${2023+i%2},2024-${String(1+i%12).padStart(2,'0')},${i%2?'Home':'Away'},${ab},${Math.round(ab*.28)},${20+i%70},${5+i%35},${i%4},${i%3?'L':'W'}\n`)}
ws.end(()=>console.log('Wrote 200,000 rows to large_sports_200k.csv'));
