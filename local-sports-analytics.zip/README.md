# Local Sports Analytics (browser-only)

A local-first sports analytics workspace. Import Excel/CSV, explore, ask grounded questions, chart, and export PDF reports — all in the browser. No backend, account, telemetry, or AI API.

## Run
```bash
npm install
npm run dev        # http://localhost:5173
npm run build      # production build (dist/)
npm test           # vitest (9 tests)
npm run generate:large   # writes large_sports_200k.csv (200,000 rows, ~17 MB) for load testing; delete after use
```

## How it works
- **Import:** Web Worker (`src/importWorker.ts`) using PapaParse (chunked CSV, 5k-row batches) and SheetJS (XLSX). **XLSX is not true streaming** — SheetJS materialises a sheet; UI warns about memory. Formula cells use stored/cached values (`cell.v`); formulas are **not** recalculated.
- **Storage:** IndexedDB (`src/storage.ts`), never localStorage for datasets. Quota errors are surfaced.
- **Engine:** dependency-light columnar engine (`src/analytics.ts`): typed columns, validated query plans compiled to a SQL-equivalent string, executed locally with row limits. This is the "equivalent embedded engine" choice instead of DuckDB-WASM to keep the bundle ~670 KB and avoid extra WASM downloads; the trade-off is fewer SQL features (no arbitrary SQL UI — intentional, read-only validated plans only).
- **Ask:** deterministic parser (`src/nl.ts`) for a documented question set + optional local LLM. Plans are strictly validated (columns, aggregations, operators whitelisted) before execution; numbers only ever come from the engine. Ambiguous "best player" asks for clarification.
- **Optional local LLM:** Settings → explicit-consent download of Phi-3-mini-4k-instruct via WebLLM/WebGPU (~2.3 GB, MLC/Hugging Face CDN; check the model card licence). Runtime is loaded from jsDelivr CDN only on click. It only *proposes* JSON plans. If WebGPU/model is unavailable, the clearly-labelled deterministic assistant remains.
- **Charts:** inline SVG (bar/line/area/scatter/histogram) with data-table equivalents, PNG export.
- **PDF:** Reports view → browser Print → Save as PDF (fully local; enable browser headers/footers for page numbers). CSV export neutralises formula injection.

## Privacy / network
Expected network requests only: (1) this app's static files, (2) **only after explicit click in Settings**, the WebLLM runtime + model weights from CDN. No dataset, prompt, schema or result is ever sent to a server. Verify in DevTools → Network.

## Tested
- Vitest: CSV quoting/newlines, XLSX duplicate headers/dates, schema inference/coercion (incl. Excel serial dates), plan validation (unknown columns/unsupported aggs rejected), batting-average denominator filter, ambiguous-question clarification, known-fixture stats/correlation (r=1), privacy guardrail (no fetch/XHR in analytics modules).
- 200k-row CSV fixture generated and parsed in Node benchmark (see summary); browser import time depends on your device — no universal performance promise.
- Reference: production build passes (`tsc` + Vite). Test in a current desktop Chrome/Edge (WebGPU) or Firefox/Safari (deterministic assistant).

## Known limitations
- ZIP import not enabled (unzip locally); XLSX memory-bound as above; no arbitrary SQL console (by design); chart points capped/sample-labelled; large filtered-search totals not precomputed; WebLLM requires WebGPU + ~2.3 GB download.

## Deploy 24/7 on Vercel (hosted, no localhost)

This is a static Vite site: there is **no server, database, or backend to keep running**.
Once deployed, Vercel's CDN serves it 24/7 at a free `*.vercel.app` URL with HTTPS.
All data processing/AI still happens in each visitor's browser — hosting changes
nothing about privacy: no user data ever reaches Vercel (or any server).

`vercel.json` is already configured (framework: Vite, build: `npm run build`, output: `dist/`).

### Option A — Deploy from GitHub (recommended, auto-redeploys on push)
1. Push this project to a GitHub repo:
   ```bash
   git init && git add . && git commit -m "Local Sports Analytics"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
2. Go to https://vercel.com → sign up (free) → **Add New → Project** → import that repo.
3. Vercel auto-detects the settings from `vercel.json` — just click **Deploy**.
4. Done: your app is live 24/7 at `https://<project>.vercel.app`. Every future `git push` redeploys automatically.

### Option B — Deploy from your computer with the Vercel CLI (no GitHub)
```bash
npm i -g vercel
vercel        # first run: log in, accept the defaults
vercel --prod # publishes the production URL
```

### Updating the live site later
Push to GitHub (Option A) or re-run `vercel --prod` (Option B). Visitors get the new version automatically; their imported datasets stay in their own browser's IndexedDB and are unaffected.
