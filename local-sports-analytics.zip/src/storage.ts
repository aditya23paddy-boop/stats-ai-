import type {Dataset} from './types';
const DB='sports-analytics-local'; 
function open():Promise<IDBDatabase>{return new Promise((res,rej)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore('datasets',{keyPath:'id'});r.onsuccess=()=>res(r.result);r.onerror=()=>rej(r.error)})}
export async function saveDataset(ds:Dataset){const db=await open();return new Promise<void>((res,rej)=>{const tx=db.transaction('datasets','readwrite');tx.objectStore('datasets').put(ds);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)})}
export async function loadDatasets():Promise<Dataset[]>{const db=await open();return new Promise((res,rej)=>{const q=db.transaction('datasets').objectStore('datasets').getAll();q.onsuccess=()=>res(q.result||[]);q.onerror=()=>rej(q.error)})}
export async function deleteDataset(id:string){const db=await open();return new Promise<void>((res,rej)=>{const tx=db.transaction('datasets','readwrite');tx.objectStore('datasets').delete(id);tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)})}
export async function clearAll(){const db=await open();return new Promise<void>((res,rej)=>{const tx=db.transaction('datasets','readwrite');tx.objectStore('datasets').clear();tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)})}
export async function storageEstimate(){if(navigator.storage?.estimate){const e=await navigator.storage.estimate();return e}return null}
