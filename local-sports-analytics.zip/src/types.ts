export type ColType='integer'|'decimal'|'date'|'boolean'|'category'|'text';
export interface ColumnMeta{name:string;internal:string;type:ColType;nulls:number;distinct:number|null;sample:(string|number|boolean|null)[];unit?:string;description?:string}
export interface Dataset{id:string;name:string;sheet:string;source:string;rows:number;cols:ColumnMeta[];data:Record<string,(string|number|boolean|null)[]>;createdAt:number;formulaNote:string}
export type Agg='count'|'sum'|'avg'|'median'|'min'|'max'|'stddev'|'variance'|'distinct'|'missing';
export interface Filter{column:string;op:'='|'!='|'>'|'>='|'<'|'<='|'contains'|'is_null'|'not_null';value?:string|number|boolean|null}
export interface Measure{column:string;agg:Agg;alias?:string}
export interface QueryPlan{intent:string;filters:Filter[];groupBy:string[];measures:Measure[];sort?:{column:string;direction:'asc'|'desc'};limit:number;chart:'bar'|'line'|'area'|'scatter'|'histogram'|'box'|'heatmap'|'table';clarification?:string;explanation?:string}
export interface QueryResult{columns:string[];rows:Record<string,any>[];rowsConsidered:number;rowsIncluded:number;sql:string;caveats:string[];plan:QueryPlan}
export const PLAN_LIMITS={maxLimit:1000,maxGroupBy:3,maxMeasures:5,maxFilters:8};
export function safeId(name:string,i:number){let s=name.trim().toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_+|_+$/g,'');if(!s||/^[0-9]/.test(s))s='col_'+s;return s+'_'+i}
export function sanitizeCell(v:any){if(typeof v==='string'&&/^[=+\-@]/.test(v))return "'"+v;return v}
