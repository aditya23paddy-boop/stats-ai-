import type {Dataset, ColumnMeta} from './types';
import {inferType, coerce} from './analytics';
import {safeId} from './types';
export function buildDataset(name:string,sheet:string,source:string,headersRaw:string[],columnsInOrder:any[][],formulaNote:string):Dataset{
 const seen=new Map<string,number>(); const headers=headersRaw.map(h=>{let base=String(h||'Column').trim()||'Column';const c=(seen.get(base)||0)+1;seen.set(base,c);return c>1?`${base} (${c})`:base});
 const data:Record<string,any[]>={}; const cols:ColumnMeta[]=headers.map((h,i)=>{const internal=safeId(h,i);const raw=columnsInOrder[i]||[];const type=inferType(raw.slice(0,5000));const vals=raw.map(v=>coerce(v,type));data[internal]=vals;return{name:h,internal,type,nulls:vals.filter(v=>v==null).length,distinct:null,sample:vals.filter(v=>v!=null).slice(0,5)}});
 return{id:Math.random().toString(36).slice(2),name,sheet,source,rows:columnsInOrder[0]?.length||0,cols,data,createdAt:Date.now(),formulaNote}}
export function demoDataset(n=2400):Dataset{
 const headers=['player','player_id','team','season','month','venue','at_bats','hits','minutes','points','goals','result'];
 const players=['A. Sharma','J. Smith','M. Patel','L. Brown','K. Tanaka','S. Garcia','T. Wilson','R. Khan','E. Müller','D. Osei']; const teams=['Chennai','Mumbai','London FC','Madrid SC'];
 const cols:any[][]=headers.map(()=>[]);
 for(let i=0;i<n;i++){const ab=20+((i*7)%180);cols[0].push(players[i%players.length]);cols[1].push(i%97===0?null:'P'+(1000+(i%players.length)));cols[2].push(teams[i%teams.length]);cols[3].push(2023+(i%2));cols[4].push(`202${3+(i%2)}-${String(1+(i%12)).padStart(2,'0')}`);cols[5].push(i%2?'Home':'Away');cols[6].push(ab);cols[7].push(Math.round(ab*(.22+((i*13)%20)/100)));cols[8].push(20+((i*3)%70));cols[9].push(Math.round(5+((i*11)%35)));cols[10].push((i*5)%4);cols[11].push(i%3===0?'W':'L')}
 return buildDataset('Demo sports data (generated locally — demo)','DemoSheet','Built-in demo',headers,cols,'Demo data generated in-browser; not real athletes.')}
