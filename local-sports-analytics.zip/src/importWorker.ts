/// <reference lib="webworker" />
import Papa from 'papaparse';
import * as XLSX from 'xlsx';
const post=(m:any)=> (self as any).postMessage(m);
self.onmessage=async(e)=>{
 const {file,delimiter,sheetWanted}=e.data;
 try{
  const ext=file.name.split('.').pop()?.toLowerCase();
  if(ext==='csv'||ext==='tsv'||ext==='txt'){
   const text=await file.text(); let rows=0,headers:string[]|null=null; const batch:any[][]=[];
   await new Promise<void>((resolve,reject)=>{Papa.parse(text,{delimiter:delimiter||(ext==='tsv'?'\t':undefined),skipEmptyLines:'greedy',step:(res:any)=>{const r=res.data as any[]; if(!headers){headers=r.map((h:any,i:number)=>String(h||`Column ${i+1}`));post({type:'headers',headers});return} if(r.every((x:any)=>x===''||x==null))return; batch.push(r); rows++; if(batch.length>=5000){post({type:'batch',rows:batch.splice(0),total:rows})} if(rows%20000===0)post({type:'progress',stage:'parsing',rows})},complete:()=>resolve(),error:(e:any)=>reject(e)})});
   if(batch.length)post({type:'batch',rows:batch,total:rows}); post({type:'done',rows,formulaNote:'CSV/TSV: values as stored in text file.'});
  } else if(ext==='zip'){post({type:'error',message:'ZIP import is not enabled in this build (to avoid an extra dependency and unbounded decompression). Please unzip locally and import CSV/XLSX files individually.'})}
  else if(ext==='xlsx'||ext==='xls'){
   post({type:'progress',stage:'reading workbook (XLSX parsing may materialize the sheet in memory)',rows:0});
   const buf=await file.arrayBuffer(); const wb=XLSX.read(buf,{type:'array',cellDates:true}); post({type:'sheets',sheets:wb.SheetNames});
   const sheetName=sheetWanted&&wb.SheetNames.includes(sheetWanted)?sheetWanted:wb.SheetNames[0]; const ws=wb.Sheets[sheetName];
   const aoa:any[][]=XLSX.utils.sheet_to_json(ws,{header:1,defval:null,raw:true}) as any[][]; const headers=(aoa[0]||[]).map((h:any,i:number)=>String(h??`Column ${i+1}`)); post({type:'headers',headers,sheet:sheetName});
   let rows=0; for(let s=1;s<aoa.length;s+=5000){const slice=aoa.slice(s,s+5000).filter(r=>r.some(v=>v!==null&&v!=='')); rows+=slice.length; post({type:'batch',rows:slice,total:rows}); post({type:'progress',stage:'parsing sheet',rows})} post({type:'done',rows,sheet:sheetName,formulaNote:'XLSX: uses stored/cached formula values from the workbook (cell.v). Formulas are NOT recalculated.'});
  } else post({type:'error',message:'Unsupported file type. Use .csv, .tsv, .xlsx or .xls.'});
 }catch(err:any){post({type:'error',message:err?.message||String(err)})}
};
