import {defineConfig} from 'vite';
export default defineConfig({worker:{format:'es'},server:{allowedHosts:true},preview:{allowedHosts:true}});
